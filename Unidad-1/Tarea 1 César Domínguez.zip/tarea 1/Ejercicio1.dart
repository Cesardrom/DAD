
void main(){
  double area_triangle(int triangle_base, int triangle_height) {
    return (triangle_base * triangle_height) / 2;
  }
  print(area_triangle(2, 10));
}



