void main() {
  List<String> nombres = ['Ana', 'Juan', 'María'];

  nombres.forEach((nombre) => print(nombre.toUpperCase()));
}
